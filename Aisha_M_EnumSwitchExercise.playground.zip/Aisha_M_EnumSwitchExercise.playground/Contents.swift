import Cocoa

var str = "Hello, playground"
//  Items I need for my perfect sandwich

enum mySandWichToppings {
    case bagel , croissant , wholeWheat , whiteBread
}
var makingSandWich = mySandWichToppings.croissant

switch  makingSandWich {
case .croissant :
    print("You chose croissant ")
case .bagel:
    print("You chose bagel"     )
case .wholeWheat:
    print("You chose wholeWheat")
case .whiteBread:
    print("You chose whiteBread")
}

enum meatToppings {
    case Ham
    case RedMeat
    case ChickenBreast
    case PlantBasedMeat
    
}
var meatChoice = meatToppings.Ham
switch meatChoice {
case . Ham :
    print("You select Ham"    )
case .RedMeat:
    print("You select RedMeat")
case .ChickenBreast:
    print("You select ChickenBreast")
    
case .PlantBasedMeat:
    print("You select PlantBasedMeat ")
    
}

enum cheeseSelection{
    case SmokedCheese , ChaddarCheese
}
var preferredCheese = cheeseSelection.SmokedCheese
switch preferredCheese {
    

case .SmokedCheese:
    print("You picked SmokedCheese")
case .ChaddarCheese:
    print("You picked ChaddarCheese ")

}
    

enum veggieLiked{
    case Tomatoes , Lettuce , Onions , Pepper

}
var veggieChoice = veggieLiked.Tomatoes
switch veggieChoice {
    
    

    
case .Tomatoes:
    print("You chose Tomatoes")
case .Lettuce:
    print("You chose Lettuce")
case .Onions:
    print("You chose Onions")
case .Pepper:
    print("You chose Pepper")

}
    
enum mayoChoice{
    case Mayo , NoMayo
}
var mayoOrNoMayo = mayoChoice.Mayo
switch mayoOrNoMayo {
    
    

case .Mayo:
    print("You like Mayo")
case .NoMayo:
    print("You like NoMayo")

}
// print "You like Mayo"
// print "You chose bagel"
print(mayoOrNoMayo)
print(meatChoice)
